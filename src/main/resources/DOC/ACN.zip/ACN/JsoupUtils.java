package jsoup;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

/**
 * ID网站：http://www.goubanjia.com
 * @author dapao
 *
 */
public class JsoupUtils {
	private static Log logger = LogFactory.getLog(JsoupUtils.class);

	private static List<String> list = new ArrayList<String>();

	/**
	 * 随机获取一个Ip地址
	 * @return
	 */
	public static String[] getRandomIp() {
		if (list.size() == 0) {
			list.add("212.77.130.65:30493");
			list.add("168.228.166.116:47059");
			list.add("54.38.202.253:54321");
			list.add("47.105.137.4:80");
			list.add("47.105.84.52:80");
			list.add("47.105.129.220:80");
			list.add("47.105.137.51:80   ");
			list.add("47.105.84.67:80");
			list.add("103.11.99.66:80");
			list.add("50.226.134.50:80");
			list.add("39.135.11.97:8080");
			list.add("111.7.130.101:8080");
			list.add("122.117.165.51:8080");
			list.add("47.105.131.35:80");
			list.add("47.105.137.135:80");
			list.add("47.105.115.176:80");
			list.add("157.65.28.91:3128");
			list.add("153.149.169.215:3128");
			list.add("140.143.105.229:80");
			list.add("117.127.0.201:8080");
		}

		Random random = new Random();
		int n = random.nextInt(list.size());
		return list.get(n).split(":");
	}

	/**
	 * Jsoup打开连接地址获取Document对象
	 * @param url
	 * @return
	 */
	public static Document getDocument(String url) {
		try {
			Connection conn = Jsoup.connect(url).ignoreContentType(true).ignoreHttpErrors(true).userAgent("Mozilla");
			// 设置代理
			String ip[] = JsoupUtils.getRandomIp();
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(ip[0].trim(), Integer.parseInt(ip[1].trim())));
			conn.proxy(proxy);
			// 设置超时时间并获取Document对象
			Document document = conn.timeout(8000).get();
			if (null != document && !StringUtils.isEmpty(document.toString())) {// 表示ip被拦截或者其他情况
				System.out.println(proxy.toString());
				return document;
			}
		} catch (Exception e) {
			logger.error("抓取失败...");
		}
		return null;
	}
}
